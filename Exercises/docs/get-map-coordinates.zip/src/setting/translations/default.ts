export default {
  selectMapWidget: "Select Map Widget",
  settings: "Settings",
  showScale: "Show Scale",
  showZoom: "Show Zoom"
};
