export default {
  _widgetLabel: "Get Map Coordinates",
  latLon: "Lat/Lon",
  zoom: "Zoom",
  latLonWillBeHere: "Lat/Lon (None - please mouse over map)"
};
